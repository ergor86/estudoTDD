<?php
require_once 'FormaPagamento.php';

interface Parceladora {
    /**
     * Gera as parcelas
     * 
     * @param float $valor Valor
     * @param DateTime $dataAtual Data atual para geração das parcelas.
     * @param FormaPagamento $fp Forma de Pagamento
     * @return array<int,Parcela>
     * 
     * * @throws RuntimeException
     */
    function gerar( float $valor, DateTime $dataAtual, FormaPagamento $fp ): array;

    
}
?>