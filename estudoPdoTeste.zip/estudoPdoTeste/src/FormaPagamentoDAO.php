<?php
require_once 'DAOException.php';

const MSG_FP_JA_EXISTE = 'Forma de pagamento já existe.';

    class FormaPagamentoDAO {
        private $pdo;

        function __construct(PDO $pdo) {
            $this->pdo = $pdo;
        }

        /**
         * Obtém uma forma de pagamento pelo id da mesma
         * @param int $id Id.
         * @return null|FormaPagamento
         */
        function obterComId(int $id): ?FormaPagamento {
            $ps = $this->pdo->prepare('SELECT * FROM forma_pagamento WHERE id = :id');
            $ps->execute(['id' => $id]);
            if ($ps->rowCount()<1){
                return null;
            }
            $ps->setFetchMode(PDO::FETCH_CLASS | PDO::FETCH_PROPS_LATE, 'FormaPagamento' );
            return $ps->fetch();
        }

        function adicionarNovo(FormaPagamento &$fp): void {
            $ps = $this->pdo->prepare('SELECT id FROM forma_pagamento WHERE descricao = ?');
            $ps->execute([$fp->descricao]);
            if ($ps->rowCount()>0){
                throw new DAOException(MSG_FP_JA_EXISTE);
            }

            $this->pdo->prepare('INSERT INTO forma_pagamento (descricao, numeroParcelas, juros)
                VALUES (:descricao, :numeroParcelas, :juros)'
                )->execute($fp->paraArray());
            $fp->id = (int) $this->pdo->lastInsertId();
        }
        
    }
?>