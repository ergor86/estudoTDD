<?php
    class DAOException extends RuntimeException{
        
    }
?>