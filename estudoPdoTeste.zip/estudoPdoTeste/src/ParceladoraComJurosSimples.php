<?php
require_once 'Parceladora.php';
require_once 'Parcela.php';

use phputil\TDate;

const MSG_PARCELADORA__VALOR_NEGATIVO = 'Valor não pode ser negativo';

class ParceladoraComJurosSimples implements Parceladora {

    /** @inheritDoc */
    function gerar( float $valor, DateTime $dataAtual, FormaPagamento $fp ): array {
        if ( $valor < 0 ) {
            throw new RuntimeException( MSG_PARCELADORA__VALOR_NEGATIVO );
        }
        $parcelas = [];
        $valorComJuros = $valor + (( $valor / 100 ) * $fp->juros);
        $valorParcela = $valorComJuros / $fp->numeroParcelas;
        $intervalo = 0;
        for ( $i = 0; $i < $fp->numeroParcelas; $i++ ) {
            $vencimento = new DateTime();
            $vencimento->add( DateInterval::createFromDateString( "$intervalo days" ) );
            $parcela = new Parcela( $vencimento, $valorParcela );
            $parcelas []= $parcela;
            $intervalo += 30;
        }
        return $parcelas;
    }


    function gerar2( float $valor, DateTime $dataAtual, FormaPagamento $fp ): array {
        if ( $valor < 0 ) {
            throw new RuntimeException( MSG_PARCELADORA__VALOR_NEGATIVO );
        }
        $parcelas = [];
        $valorComJuros = $valor + (( $valor / 100 ) * $fp->juros);
        $valorParcela = $valorComJuros / $fp->numeroParcelas;
        $vencimento = ( new TDate() )->copy( $dataAtual );
        for ( $i = 0; $i < $fp->numeroParcelas; $i++ ) {
            $parcela = new Parcela( $vencimento, $valorParcela );
            $parcelas []= $parcela;
            $vencimento = clone $vencimento;
            $vencimento->addDays( 30 );
        }
        return $parcelas;
    }
}

?>