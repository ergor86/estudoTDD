<?php
    class FormaPagamento {
        public  $id;
        public  $descricao;
        public  $numeroParcelas;
        public $juros;

        function __construct(
            int $id = 0,
            string $descricao = '',
            int $numeroParcelas = 0,
            float $juros = 0.0
        ) {
            $this->id = $id;
            $this->descricao = $descricao;
            $this->numeroParcelas = $numeroParcelas;
            $this->juros = $juros;
        }

        function paraArray(){
            return [
                'descricao' => $this->descricao,
                'numeroParcelas' =>$this->numeroParcelas,
                'juros' =>$this->juros
            ];
        }
    }
?>