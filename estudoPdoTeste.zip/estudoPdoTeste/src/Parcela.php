<?php
    class Parcela {
        public $vencimento;
        public  $valor;

        function __construct(
            ?DateTime $vencimento = null,
            float $valor =0.0
        ){
            $this->vencimento = $vencimento;
            $this->valor = $valor;
        }
    }
?>