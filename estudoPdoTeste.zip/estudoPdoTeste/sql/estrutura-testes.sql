-- pk - primary key
-- fk - foreign key
-- unq - unique
-- idx - index

CREATE DATABASE IF NOT EXISTS `testes-php`
    DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;

USE `testes-php`;

DROP TABLE IF EXISTS forma_pagamento;

CREATE TABLE forma_pagamento (
    id INT NOT NULL AUTO_INCREMENT,
    descricao VARCHAR(100) NOT NULL,
    numeroParcelas INT DEFAULT 0,
    juros DECIMAL(5,2) NOT NULL,
    CONSTRAINT pk_forma_pagamento PRIMARY KEY( id ),
    CONSTRAINT unq_forma_pagamento__descricao UNIQUE( descricao )
) ENGINE=memory;
