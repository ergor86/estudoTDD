INSERT INTO forma_pagamento
(id,descricao,numeroParcelas,juros)
VALUES
(NULL, 'Dez vezes', 10,10.00),
(NULL, 'Quinze vezes', 15,12.00),
(NULL, 'Vinte vezes', 20,15.00),
(NULL, 'Trinta e seis vezes', 36, 20.00);