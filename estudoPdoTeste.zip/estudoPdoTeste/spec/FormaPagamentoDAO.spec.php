<?php
    require_once 'src/FormaPagamento.php';
    require_once 'src/FormaPagamentoDAO.php';

    describe('FormaPagamentoDAO', function(){
        $this->pdo = new PDO('mysql:dbname=testes-php;host=localhost;charset=utf8',
         'root', '',[PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);

        beforeAll(function(){
            $this->pdo->exec(file_get_contents('sql/estrutura-testes.sql'));
             // Limpa a tabela
            // $this->pdo->exec( 'DELETE FROM forma_pagamento' );
            // Insere os dados iniciais, utilizados pelos testes
            $this->pdo->exec(file_get_contents('sql/dados/forma_pagamento.sql'));
        });
        describe('obterComId', function(){
            it('obtém uma forma de pagamento existente', function(){
                $dao = new FormaPagamentoDAO($this->pdo); //instancia o obj dao passando conexao
                $fp = $dao->obterComId(1);
                expect($fp)->not->toBeNull();
                expect($fp)->toBeAnInstanceOf('FormaPagamento');

            });
            it('retorna nulo quando a forma de pagamento não existente', function(){
                $dao = new FormaPagamentoDAO($this->pdo);
                $fp = $dao->obterComId(0);
                expect($fp)->toBeNull();
            });
        });

        describe('adicionarNovo', function(){
            it('gera um id para a forma de pagamento', function(){
                $fp = new FormaPagamento(0, 'Vinte e quatro vezes', 24, 25.00);
                $dao = new FormaPagamentoDAO($this->pdo);
                $dao->adicionarNovo($fp);
                expect($fp->id)->not->toBe(0);
            });
        });

            it('Adiciona uma forma de pagamento', function(){
                $fp = new FormaPagamento(0, 'Cinco vezes', 5,5.00);
                $dao = new FormaPagamentoDAO($this->pdo);
                $dao->adicionarNovo($fp);
                $fp2 = $dao->obterComId($fp->id);
                expect($fp2->id)->toBeCloseTo($fp->id);
            });

            it('lança exceção ao adicionar uma forma de pagamento repetida', function(){
                $fp = new FormaPagamento(0,'Dez vezes', 10, 10.00);
                $dao = new FormaPagamentoDAO($this->pdo);
                expect(function() use ($fp, $dao){
                    $dao->adicionarNovo($fp);
                })->toThrow(MSG_FP_JA_EXISTE);
            });
    });
?>