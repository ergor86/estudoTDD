<?php
require_once 'vendor/autoload.php';
require_once 'src/ParceladoraComJurosSimples.php';

use phputil\TDate;

describe( 'ParceladoraComJurosSimples', function() {

    it( 'retorna parcela com juros aplicado', function() {
        $fp = new FormaPagamento( 0, '', 1, 10.00 );
        $parceladora = new ParceladoraComJurosSimples();
        $parcelas = $parceladora->gerar( 100.00, new DateTime(), $fp );
        expect( $parcelas )->toHaveLength( 1 );
        [ $primeira ] = $parcelas;
        expect( $primeira->valor )->toBeCloseTo( 110.00 );
    } );

    it( 'gera duas parcelas que perfazem o valor total', function() {
        $fp = new FormaPagamento( 0, '', 2, 10.00 );
        $parceladora = new ParceladoraComJurosSimples();
        $parcelas = $parceladora->gerar( 100.00, new DateTime(), $fp );
        expect( $parcelas )->toHaveLength( 2 );
        [ $primeira, $segunda ] = $parcelas;
        expect( $primeira->valor + $segunda->valor )->toBeCloseTo( 110.00 );
    } );

    // TODO: 2) gerar verificação para duas parcelas, com valor total de R$ 333,33
    xit( 'gera duas parcelas que perfazem o valor total com valor não divisível exatamente por dois', function() {
        $fp = new FormaPagamento( 0, '', 2, 0.00 );
        $parceladora = new ParceladoraComJurosSimples();
        $parcelas = $parceladora->gerar( 333.33, new DateTime(), $fp );
        expect( $parcelas )->toHaveLength( 2 );
        [ $primeira, $segunda ] = $parcelas;
        expect( $primeira->valor + $segunda->valor )->toBeCloseTo( 333.33 );
        // expect( (string) $primeira->valor )->toEqual( '166.67' );
        expect( $primeira->valor )->toBeCloseTo( 166.67, 3 );
        expect( $segunda->valor )->toBeCloseTo( 166.66, 3 );
    } );

    it( 'lança exceção ao passar valor negativo', function() {
        expect( function() {
            $fp = new FormaPagamento( 0, '', 2, 0.00 );
            $parceladora = new ParceladoraComJurosSimples();
            $parceladora->gerar( -0.01, new DateTime(), $fp );
        } )->toThrow( MSG_PARCELADORA__VALOR_NEGATIVO );
    } );


    it( 'primeira parcela gerada deve ser 0 dias após a primeira', function() {
        $fp = new FormaPagamento( 0, '', 2, 0.00 );
        $parceladora = new ParceladoraComJurosSimples();
        $hoje = new DateTime();
        [ $primeira ] = $parceladora->gerar( 100.00, $hoje, $fp );

        $diffDias = (int) $hoje->diff( $primeira->vencimento )->format( '%a' );
        expect( $diffDias )->toEqual( 0 );
    } );

    it( 'segunda parcela gerada deve ser 30 dias após a primeira', function() {
        $fp = new FormaPagamento( 0, '', 2, 0.00 );
        $parceladora = new ParceladoraComJurosSimples();
        $hoje = new DateTime();
        [ , $segunda ] = $parceladora->gerar( 100.00, $hoje, $fp );

        $umMesDepois = ( new DateTime() )->add( DateInterval::createFromDateString( '30 days' ) );
        $diffDias = (int) $umMesDepois->diff( $segunda->vencimento )->format( '%a' );
        expect( $diffDias )->toEqual( 0 );
    } );

    it( 'segunda parcela gerada deve ser 30 dias após a primeira - v2', function() {
        $fp = new FormaPagamento( 0, '', 2, 0.00 );
        $parceladora = new ParceladoraComJurosSimples();
        $hoje = new DateTime();
        [ , $segunda ] = $parceladora->gerar2( 100.00, $hoje, $fp );

        $umMesDepois = ( new TDate() )->copy( $hoje )->addDays( 30 );
        expect( $umMesDepois->diffInDays( $segunda->vencimento ) )->toEqual( 0 );
    } );

} );
?>